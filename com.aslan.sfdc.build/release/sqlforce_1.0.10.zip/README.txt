
This directory should contain the following files:

+ sqlforce.jar - the code as an executable jar (java -jar sqlforce.jar)
+ README.txt - this file
+ SQLForce.py - a Jython module wrapper for SQLForce
+ doc -- use cases that explain the grammar supported by SQLForce

Start by reading doc/ReadMeFirst.html.


